<?php include __DIR__ . '/header.php'; ?>

<div class="container mt-5">
    <div id="content" class="flex-fill">
        <div class="text-center">
            <?= $content ?>
        </div>
    </div>
</div>

<?php include __DIR__ . '/footer.php'; ?>
