<div class="text-center">
    <h1>Welcome to ITVO</h1>
    <p>This placeholder is for dynamic content.</p>
</div>